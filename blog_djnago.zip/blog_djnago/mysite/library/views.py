from django.shortcuts import render, get_object_or_404, redirect, reverse
from django.http import HttpResponse, HttpResponseRedirect
from .models import Camp, CampInstance, ChildrenCamp, CampInstance
from django.contrib.auth.forms import User
from django.views.decorators.csrf import csrf_protect
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .forms import UserUpdateForm, ProfilisUpdateForm, CampReviewForm
from django.urls import reverse
from django.views import View
from .models import Camp, CampReview

@login_required
def camp_detail(request, pk):
    
    # form = CampReviewForm(request.POST or None)

    # if form.is_valid():
    #     form.instance.camp = camp
    #     form.instance.reviewer = request.user
    #     form.save()
    #     return redirect(reverse('camp-detail', kwargs={'pk': camp.pk}))

    if request.method == 'POST':
        camp = get_object_or_404(Camp, pk=pk)
        print('veikia')
        content = request.POST['comment']
        review = CampReview(camp=camp, reviewer=request.user, content=content )
        review.save()
        return redirect('camp')
    camp = get_object_or_404(Camp, pk=pk)
    context = {
        'object': camp,
        # 'form': form
    }
    return render(request, 'camp.html', context)


@login_required
def profilis(request):
    return render(request, 'profilis.html')


def index(request):
    return render(request, 'index.html')

def about(request):
    return render(request, 'about.html')

def calendar(request):
    num_camp = Camp.objects.all().count()
    num_instances = CampInstance.objects.all().count()
    
    num_instances_available = CampInstance.objects.filter(status__exact='g').count()

    num_childrenCamp = ChildrenCamp.objects.all().count()
    
    context = {
        'num_camp': num_camp,
        'num_instances': num_instances,
        'num_instances_available': num_instances_available,
        'num_childrenCamp': num_childrenCamp,


    }
    
    return render(request, 'calendar.html', context=context)


def camps (request):
    camps = Camp.objects.all()
    context = {
        'camps': camps
    }
    print(camps)
    return render(request, 'camps.html', context=context)

def camp(request, camp_id):
    single_camp = get_object_or_404(Camp, pk=camp_id)
    return render(request, 'camp.html', {'camp': single_camp})

def loaned_camps_by_user_list_view(request):
    queryset = CampInstance.objects.filter(consumer=request.user).filter(status__exact='p').order_by('due_back')
    context = {
        'object_list': queryset,
    }
    return render(request, 'myreservation.html', context=context)








@csrf_protect
def register(request):
    if request.method == "POST":
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        password2 = request.POST['password2']

        if password == password2:
            if User.objects.filter(username=username).exists():
                messages.error(request, f'Vartotojo vardas {username} užimtas!')
                return redirect('register')
            else:
                if User.objects.filter(email=email).exists():
                    messages.error(request, f'Vartotojas su el. paštu {email} jau užregistruotas!')
                    return redirect('register')
                else:
                    User.objects.create_user(username=username, email=email, password=password)
                    messages.info(request, f'Vartotojas {username} užregistruotas!')
                    return redirect('login')
        else:
            messages.error(request, 'Slaptažodžiai nesutampa!')
            return redirect('register')
    return render(request, 'register.html')

@login_required
def profilis(request):
    if request.method == "POST":
        u_form = UserUpdateForm(request.POST, instance=request.user)
        p_form = ProfilisUpdateForm(request.POST, request.FILES, instance=request.user.profilis)
        if u_form.is_valid() and p_form.is_valid():
            u_form.save()
            p_form.save()
            messages.success(request, f"Profilis atnaujintas")
            return redirect('profilis')
    else:
        u_form = UserUpdateForm(instance=request.user)
        p_form = ProfilisUpdateForm(instance=request.user.profilis)

    context = {
        'u_form': u_form,
        'p_form': p_form,
    }
    return render(request, 'profilis.html', context)