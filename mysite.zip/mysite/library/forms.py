from django import forms
from .models import Profilis, CampReview, Reservation
from django.contrib.auth.models import User
from django.forms import DateInput

class ReservationForm(forms.ModelForm):
    check_in = forms.DateField(widget=DateInput(attrs={'type': 'date'}))
    check_out = forms.DateField(widget=DateInput(attrs={'type': 'date'}))
    class Meta:
        model = Reservation
        fields = ['campsite', 'check_in', 'check_out']
        widgets = {'user': forms.HiddenInput()}


class CampReviewForm(forms.ModelForm):
    class Meta:
        model = CampReview
        fields = ('content', 'camp', 'reviewer')
        widgets = {'camp': forms.HiddenInput(), 'reviewer': forms.HiddenInput()}




class UserUpdateForm(forms.ModelForm):
    email = forms.EmailField()

    class Meta:
        model = User
        fields = ['username', 'email']


class ProfilisUpdateForm(forms.ModelForm):
    class Meta:
        model = Profilis
        fields = ['nuotrauka']



